from setuptools import setup

setup(name='mowitnow',
      version='0.1',
      description='MowItNow controller',
      url='https://github.com/xavbyme/mowitnow.git',
      author='XRU',
      author_email='ruiz.xvr@gmail.com',
      license='MIT',
      packages=['mowitnow'],
      zip_safe=False)